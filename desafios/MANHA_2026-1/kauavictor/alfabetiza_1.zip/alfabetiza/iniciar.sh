#!/bin/bash

echo "======================================"
echo "   Alfabetiza IMIP - Iniciando...     "
echo "======================================"
echo ""

cd "$(dirname "$0")"

echo "[1/2] Instalando dependências..."

# Tenta pip normal, se falhar usa venv
if pip install -r requirements.txt 2>/dev/null; then
    echo "Dependências instaladas com sucesso."
else
    echo "Criando ambiente virtual..."
    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo ""
        echo "ERRO: Falha ao instalar dependências."
        exit 1
    fi
fi

echo ""
echo "[2/2] Iniciando o servidor..."
echo ""
echo "  → Acesse: http://localhost:5000"
echo "  → Para encerrar: Ctrl+C"
echo ""

# Ativa venv se existir
[ -f ".venv/bin/activate" ] && source .venv/bin/activate

python run.py
