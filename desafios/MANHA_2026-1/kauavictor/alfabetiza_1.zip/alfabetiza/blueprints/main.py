from flask import Blueprint, render_template, request, jsonify, current_app
from flask_login import login_required, current_user
from models import db, Historia
import urllib.request
import json
import random

main_bp = Blueprint("main", __name__)

TEMAS = [
    "animais da floresta amazônica",
    "o fundo do mar e seus habitantes",
    "uma fazenda com animais amigos",
    "uma viagem ao espaço sideral",
    "crianças brincando no parque",
    "uma aventura no jardim encantado",
    "o mundo colorido das frutas",
    "amigos explorando a cidade",
    "um dia especial na escola",
    "a magia das estações do ano",
]


def gerar_historia_llama(tema: str) -> dict:
    api_key = current_app.config["OPENROUTER_API_KEY"]

    prompt = f"""Crie uma história infantil curta e educativa para alfabetização, com tema: {tema}.

A história deve:
- Ter entre 150 e 200 palavras
- Usar linguagem simples, adequada para crianças de 6 a 12 anos
- Ter início, meio e fim bem definidos
- Incluir uma moral ou lição positiva
- Usar frases curtas e vocabulário acessível
- Ser alegre, lúdica e encorajadora

Formato de resposta (JSON):
{{
  "titulo": "Título criativo da história",
  "historia": "Texto completo da história aqui..."
}}

Responda APENAS com o JSON, sem nenhum texto adicional."""

    payload = json.dumps({
        "model": "meta-llama/llama-4-scout",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.8,
        "max_tokens": 600,
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://openrouter.ai/api/v1/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://alfabetiza-imip.app",
            "X-Title": "Alfabetiza IMIP",
        },
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    conteudo = data["choices"][0]["message"]["content"].strip()

    # Extrair JSON da resposta
    inicio = conteudo.find("{")
    fim = conteudo.rfind("}") + 1
    if inicio != -1 and fim > inicio:
        conteudo = conteudo[inicio:fim]

    resultado = json.loads(conteudo)
    return resultado


@main_bp.route("/")
@login_required
def index():
    historias = (
        Historia.query
        .filter_by(user_id=current_user.id)
        .order_by(Historia.criada_em.desc())
        .limit(5)
        .all()
    )
    return render_template("index.html", historias=historias)


@main_bp.route("/gerar-historia", methods=["POST"])
@login_required
def gerar_historia():
    try:
        tema = random.choice(TEMAS)
        resultado = gerar_historia_llama(tema)

        titulo = resultado.get("titulo", "Minha Historinha")
        texto = resultado.get("historia", "")

        historia = Historia(
            titulo=titulo,
            conteudo=texto,
            user_id=current_user.id,
        )
        db.session.add(historia)
        db.session.commit()

        return jsonify({
            "ok": True,
            "id": historia.id,
            "titulo": titulo,
            "historia": texto,
            "tema": tema,
        })

    except Exception as e:
        return jsonify({"ok": False, "erro": str(e)}), 500


@main_bp.route("/historia/<int:historia_id>")
@login_required
def ver_historia(historia_id):
    historia = Historia.query.get_or_404(historia_id)
    return jsonify({
        "titulo": historia.titulo,
        "historia": historia.conteudo,
    })
