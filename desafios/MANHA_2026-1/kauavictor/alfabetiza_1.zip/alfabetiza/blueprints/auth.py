from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required
from models import db, User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        confirmar = request.form.get("confirmar", "")

        if not nome or not email or not senha:
            flash("Preencha todos os campos.", "erro")
            return render_template("registro.html")

        if senha != confirmar:
            flash("As senhas não coincidem.", "erro")
            return render_template("registro.html")

        if User.get_by_email(email):
            flash("Este e-mail já está cadastrado.", "erro")
            return render_template("registro.html")

        usuario = User(nome=nome, email=email)
        usuario.set_password(senha)
        db.session.add(usuario)
        db.session.commit()

        login_user(usuario)
        flash(f"Bem-vindo(a), {nome}! Sua conta foi criada.", "sucesso")
        return redirect(url_for("main.index"))

    return render_template("registro.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")

        usuario = User.get_by_email(email)
        if usuario and usuario.verify_password(senha):
            login_user(usuario)
            proxima = request.args.get("next")
            return redirect(proxima or url_for("main.index"))

        flash("E-mail ou senha incorretos.", "erro")

    return render_template("login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
