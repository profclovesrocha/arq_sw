@echo off
chcp 65001 >nul
echo ======================================
echo    Alfabetiza IMIP - Iniciando...
echo ======================================
echo.

cd /d "%~dp0"

echo [1/2] Instalando dependencias...

pip install -r requirements.txt >nul 2>&1
if %errorlevel% neq 0 (
    echo Criando ambiente virtual...
    python -m venv .venv
    call .venv\Scripts\activate.bat
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo.
        echo ERRO: Falha ao instalar dependencias.
        pause
        exit /b 1
    )
) else (
    echo Dependencias instaladas com sucesso.
    if exist ".venv\Scripts\activate.bat" call .venv\Scripts\activate.bat
)

echo.
echo [2/2] Iniciando o servidor...
echo.
echo   ^> Acesse: http://localhost:5000
echo   ^> Para encerrar: Ctrl+C
echo.

python run.py
pause
